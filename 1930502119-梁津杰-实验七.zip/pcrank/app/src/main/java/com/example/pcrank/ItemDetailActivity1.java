package com.example.pcrank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class ItemDetailActivity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail1);
        TextView rank=findViewById(R.id.rank);
        TextView pc=findViewById(R.id.pc);
        TextView num=findViewById(R.id.num);
        Intent intent = getIntent();
        String rankx = intent.getStringExtra("rank");
        String pcx = intent.getStringExtra("pc");
        String numx = intent.getStringExtra("numbers");
        rank.setText(rankx);
        pc.setText(pcx);
        num.setText(numx);
    }
}