package com.example.pcrank;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class rankAdapter extends ArrayAdapter<pcrank> {
    private int id;
    public rankAdapter(Context context, int textViewResourceId, List<pcrank>objects){
        super(context,textViewResourceId,objects);
        id=textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        pcrank rk=getItem(position);
        View view= LayoutInflater.from((getContext())).inflate(id,parent,false);
//        View view= LayoutInflater.from((getContext())).inflate(id,null);
        TextView rank=(TextView)view.findViewById(R.id.rank0);
        TextView pc=(TextView)view.findViewById(R.id.pc);
        TextView num=(TextView)view.findViewById(R.id.num);
        System.out.println("3-0");
        Log.v("MainActivity","3-0");
        rank.setText(rk.getPcrankx());
        System.out.println("3-1-1");
        Log.v("MainActivity","3-1-1");
        pc.setText(rk.getName());
        System.out.println("3-1-2");
        Log.v("MainActivity","3-1-2");
        num.setText(rk.getNum());
        System.out.println("3-1-3");
        Log.v("MainActivity","3-1-3");
        return view;
    }
}
