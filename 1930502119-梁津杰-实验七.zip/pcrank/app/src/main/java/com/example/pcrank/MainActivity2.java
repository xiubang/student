package com.example.pcrank;


import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity2 extends Activity {


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main2);
        TextView title= findViewById(R.id.title);
        TextView date= findViewById(R.id.date);
        TextView details= findViewById(R.id.details);

//        ArrayAdapter<String> title=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,pc);
//        ArrayAdapter<String> pdate=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,pc1);
//
//        rank1.setAdapter(pc0);
//        rank2.setAdapter(pc2);
    }
}