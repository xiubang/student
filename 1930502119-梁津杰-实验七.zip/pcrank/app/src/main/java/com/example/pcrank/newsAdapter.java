package com.example.pcrank;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class newsAdapter extends ArrayAdapter<News> {
    private int id;
    public newsAdapter(Context context, int textViewResourceId, List<News> objects){
        super(context,textViewResourceId,objects);
        id=textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        News news =getItem(position);
        View view= LayoutInflater.from((getContext())).inflate(id,parent,false);
//        View view= LayoutInflater.from((getContext())).inflate(id,null);
        TextView title=(TextView)view.findViewById(R.id.title);
        TextView date=(TextView)view.findViewById(R.id.date);
        TextView details=(TextView)view.findViewById(R.id.details);
        System.out.println("3-0");
        Log.v("MainActivity","3-0");
        title.setText(news.getTitle());
        System.out.println("3-1-1");
        Log.v("MainActivity","3-1-1");
        date.setText(news.getDate());
        System.out.println("3-1-2");
        Log.v("MainActivity","3-1-2");
        details.setText(news.getDeatils());
        System.out.println("3-1-3");
        Log.v("MainActivity","3-1-3");
        return view;
    }
}

