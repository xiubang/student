package com.example.pcrank;

public class pcrank {
    private String pcrankx;
    private String name;
    private String num;

    public pcrank(String pcrankx, String name, String num) {
        this.pcrankx = pcrankx;
        this.name = name;
        this.num = num;
    }

    public pcrank() {
    }

    @Override
    public String toString() {
        return "pcrank{" +
                "pcrankx=" + pcrankx +
                ", name='" + name + '\'' +
                ", num=" + num +
                '}';
    }

    public String getPcrankx() {
        return pcrankx;
    }

    public void setPcrankx(String pcrankx) {
        this.pcrankx = pcrankx;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }
}
