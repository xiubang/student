package com.example.pcrank;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private List<pcrank> pcrank= new ArrayList<>();
    private final String[] pc0={"联想","戴尔","华硕","苹果","惠普","宏基","索尼","三星","神舟","东芝"};
    private final String[] pc1={"510947","225193","225513","181891","91470","72139","64158","52514","35647","20994"};
/*
电池
 */
    private IntentFilter mIntentFilter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//电池相关
//        mIntentFilter = new IntentFilter();
//        mIntentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);

        Intent intent2 = new Intent();
        intent2.setAction("com.broadcast.mybroadcast");
        intent2.putExtra("receiver", "myreicerver");
        //无序广播
        this.sendBroadcast(intent2);


        System.out.println("0");
        setContentView(R.layout.activity_main);
        System.out.println("1");
        initpcrank();
        System.out.println("2");
        rankAdapter adapter=new rankAdapter(MainActivity.this,
                R.layout.rank_item,pcrank);
        System.out.println("3");
        ListView lv= (ListView) findViewById(R.id.pcrankx);
        System.out.println("4");
        lv.setAdapter(adapter);
        System.out.println("5");
        lv.setOnItemClickListener((parent, view, position, id) -> {
            pcrank pcx = pcrank.get(position);
            Toast.makeText(MainActivity.this, pcx.getName(),
                    Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, ItemDetailActivity1.class);
            intent.putExtra("rank",pcx.getPcrankx());
            intent.putExtra("pc",pcx.getName());
            intent.putExtra("numbers",pcx.getNum());
            startActivity(intent);
        });

    }

    private void initpcrank(){
        for(int i=0;i<10;i++){
            pcrank pc=new pcrank();
            pc.setPcrankx(Integer.toString(i+1));
            pc.setName(pc0[i]);
            pc.setNum(pc1[i]);
            pcrank.add(pc);
        }

        /*---控制台输出---*/
        System.out.println("------一共有："+pcrank.size()+"个");
        for(int i=0;i<10;i++){
            System.out.println("------第"+i+"个："+pcrank.get(i).toString());
        }
    }
}
/*
    //声明消息处理过程
    private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            int status = intent.getIntExtra("status", 0);
            int health = intent.getIntExtra("health", 0);
            boolean present = intent.getBooleanExtra("present", false);
            int level = intent.getIntExtra("level", 0);
            int scale = intent.getIntExtra("scale", 0);
            int icon_small = intent.getIntExtra("icon-small", 0);
            int plugged = intent.getIntExtra("plugged", 0);
            int voltage = intent.getIntExtra("voltage", 0);
            int temperature = intent.getIntExtra("temperature", 0);
            String technology = intent.getStringExtra("technology");
            String statusString = "";
            switch (status) {
                case BatteryManager.BATTERY_STATUS_UNKNOWN:
                    statusString = "unknown";
                    break;
                case BatteryManager.BATTERY_STATUS_CHARGING:
                    statusString = "charging";
//                    battery_image.setImageResource(R.drawable.stat_sys_battery_charge);
//                    battery_image.getDrawable().setLevel(level);
                    break;
                case BatteryManager.BATTERY_STATUS_DISCHARGING:
                    statusString = "discharging";
//                    battery_image.setImageResource(R.drawable.stat_sys_battery);
//                    battery_image.getDrawable().setLevel(level);
                    break;
                case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                    statusString = "not charging";
                    break;
                case BatteryManager.BATTERY_STATUS_FULL:
                    statusString = "full";
                    break;
            }
            String healthString = "";
            switch (health) {
                case BatteryManager.BATTERY_HEALTH_UNKNOWN:
                    healthString = "unknown";
                    break;
                case BatteryManager.BATTERY_HEALTH_GOOD:
                    healthString = "good";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                    healthString = "overheat";
                    break;
                case BatteryManager.BATTERY_HEALTH_DEAD:
                    healthString = "dead";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                    healthString = "voltage";
                    break;
                case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                    healthString = "unspecified failure";
                    break;
            }
            String acString = "";
            switch (plugged) {
                case BatteryManager.BATTERY_PLUGGED_AC:
                    acString = "plugged ac";
                    break;
                case BatteryManager.BATTERY_PLUGGED_USB:
                    acString = "plugged usb";
                    break;
            }
            Log.i("cat", statusString);
            Log.i("cat", healthString);
            Log.i("cat", String.valueOf(present));
            Log.i("cat", String.valueOf(level));
            Log.i("cat", String.valueOf(scale));
            Log.i("cat", String.valueOf(icon_small));
            Log.i("cat", acString);
            Log.i("cat", String.valueOf(voltage));
            Log.i("cat", String.valueOf(temperature));
            Log.i("cat", technology);
            //要看看是不是我们要处理的消息
            if (action.equals(Intent.ACTION_BATTERY_CHANGED)) {
                //电池电量，数字
                Log.d("Battery", "" + intent.getIntExtra("level", 0));
                //电池最大容量
                Log.d("Battery", "" + intent.getIntExtra("scale", 0));
                //电池伏数
                Log.d("Battery", "" + intent.getIntExtra("voltage", 0));
                //电池温度
                Log.d("Battery", "" + intent.getIntExtra("temperature", 0));
                //电池状态，返回是一个数字
                // BatteryManager.BATTERY_STATUS_CHARGING 表示是充电状态
                // BatteryManager.BATTERY_STATUS_DISCHARGING 放电中
                // BatteryManager.BATTERY_STATUS_NOT_CHARGING 未充电
                // BatteryManager.BATTERY_STATUS_FULL 电池满
                Log.d("Battery", "ss" + intent.getIntExtra("status", BatteryManager.BATTERY_STATUS_CHARGING));
                //充电类型 BatteryManager.BATTERY_PLUGGED_AC 表示是充电器，不是这个值，表示是 USB
                Log.d("Battery", "" + intent.getIntExtra("plugged", 0));
                //电池健康情况，返回也是一个数字
                //BatteryManager.BATTERY_HEALTH_GOOD 良好
                //BatteryManager.BATTERY_HEALTH_OVERHEAT 过热
                //BatteryManager.BATTERY_HEALTH_DEAD 没电
                //BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE 过电压
                //BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE 未知错误
                Log.d("Battery", "" + intent.getIntExtra("health", BatteryManager.BATTERY_HEALTH_UNKNOWN));
            }
        }
    };
 */