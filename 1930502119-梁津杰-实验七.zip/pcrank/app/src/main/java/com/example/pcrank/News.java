package com.example.pcrank;

public class News {
    private String title;
    int date;
    private String deatils;

    public News() {
    }

    public News(String title, int date, String deatils) {
        this.title = title;
        this.date = date;
        this.deatils = deatils;
    }

    @Override
    public String toString() {
        return "News{" +
                "title='" + title + '\'' +
                ", date=" + date +
                ", deatils='" + deatils + '\'' +
                '}';
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public String getDeatils() {
        return deatils;
    }

    public void setDeatils(String deatils) {
        this.deatils = deatils;
    }
}
