package com.example.pcrank;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.widget.Toast;


    public class power extends Activity {
        private BatteryChangedReceiver receiver = new BatteryChangedReceiver();

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            registerReceiver(receiver, getFilter());
        }

        private IntentFilter getFilter() {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_BATTERY_CHANGED);
            filter.addAction(Intent.ACTION_BATTERY_LOW);
            filter.addAction(Intent.ACTION_BATTERY_OKAY);
            return filter;
        }

        @Override
        protected void onDestroy() {
            // TODO Auto-generated method stub
            unregisterReceiver(receiver);
            super.onDestroy();
        }

        class BatteryChangedReceiver extends BroadcastReceiver {

            @Override
            public void onReceive(Context context, Intent intent) {
                // TODO Auto-generated method stub
                final String action = intent.getAction();
                if (action.equalsIgnoreCase(Intent.ACTION_BATTERY_CHANGED)) {
                    System.out
                            .println("BatteryChangedReceiver BATTERY_CHANGED_ACTION---");
                    // 当前电池的电压
                    int voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE,
                            -1);
                    // 电池的健康状态
                    int health = intent
                            .getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
                    switch (health) {
                        case BatteryManager.BATTERY_HEALTH_COLD:
                            Toast.makeText(power.this, "BATTERY_HEALTH_COLD  电池低温", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_HEALTH_DEAD:
                            Toast.makeText(power.this, "BATTERY_HEALTH_DEAD  电池异常", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_HEALTH_GOOD:
                            Toast.makeText(power.this, "BATTERY_HEALTH_GOOD  电池正常", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                            Toast.makeText(power.this, "BATTERY_HEALTH_OVERHEAT  电池高温", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                            Toast.makeText(power.this, "BATTERY_HEALTH_COLD 电池低温", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_HEALTH_UNKNOWN:
                            Toast.makeText(power.this, "BATTERY_HEALTH_UNKNOWN  电池未知", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                            Toast.makeText(power.this, "BATTERY_HEALTH_UNSPECIFIED_FAILURE  电池状态无法识别", Toast.LENGTH_LONG).show();
                            break;
                        default:
                            break;
                    }
                    // 电池当前的电量, 它介于0和 EXTRA_SCALE之间
                    int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    // 电池电量的最大值
                    int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    // 当前手机使用的是哪里的电源
                    int pluged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED,
                            -1);
                    switch (pluged) {
                        case BatteryManager.BATTERY_PLUGGED_AC:
                            // 电源是AC charger.[应该是指充电器]
                            Toast.makeText(power.this, "BATTERY_PLUGGED_AC  交流电充电器", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_PLUGGED_USB:
                            // 电源是USB port
                            Toast.makeText(power.this, "BATTERY_PLUGGED_USB  接口", Toast.LENGTH_LONG).show();
                            break;
                        default:
                            break;
                    }
                    int status = intent
                            .getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                    switch (status) {
                        case BatteryManager.BATTERY_STATUS_CHARGING:
                            // 正在充电
                            Toast.makeText(power.this, "BATTERY_STATUS_CHARGING  正在充电", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_STATUS_DISCHARGING:
                            Toast.makeText(power.this, "BATTERY_STATUS_DISCHARGING  无正在充电", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_STATUS_FULL:
                            // 充满
                            Toast.makeText(power.this, "BATTERY_STATUS_FULL  已经充满", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                            // 没有充电
                            Toast.makeText(power.this, "BATTERY_STATUS_NOT_CHARGING  无充电", Toast.LENGTH_LONG).show();
                            break;
                        case BatteryManager.BATTERY_STATUS_UNKNOWN:
                            // 未知状态
                            Toast.makeText(power.this, "BATTERY_STATUS_UNKNOWN  未知状态（异常）", Toast.LENGTH_LONG).show();
                            break;
                        default:
                            break;
                    }
                    // 电池使用的技术。比如，对于锂电池是Li-ion
                    String technology = intent
                            .getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
                    // 当前电池的温度
                    int temperature = intent.getIntExtra(
                            BatteryManager.EXTRA_TEMPERATURE, -1);
                    Toast.makeText(power.this, "voltage = " + voltage + " technology = "
                            + technology + " temperature = " + temperature
                            + " level = " + level + " scale = " + scale, Toast.LENGTH_LONG).show();
                } else if (action.equalsIgnoreCase(Intent.ACTION_BATTERY_LOW)) {
                    // 表示当前电池电量低
                    Toast.makeText(power.this, "BatteryChangedReceiver ACTION_BATTERY_LOW---低电量", Toast.LENGTH_LONG).show();
                } else if (action.equalsIgnoreCase(Intent.ACTION_BATTERY_OKAY)) {
                    // 表示当前电池已经从电量低恢复为正常
                    Toast.makeText(power.this, "BatteryChangedReceiver ACTION_BATTERY_OKAY---正常电量", Toast.LENGTH_LONG).show();
                }
            }

        }
    }
