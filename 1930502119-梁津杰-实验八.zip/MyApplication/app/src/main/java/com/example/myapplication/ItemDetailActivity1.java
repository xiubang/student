package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ItemDetailActivity1 extends AppCompatActivity {
    private List<book> book = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail1);
        TextView booktype=findViewById(R.id.booktype);
        TextView bookname=findViewById(R.id.bookname);
        Intent intent = getIntent();
        book =  (ArrayList<book>) getIntent().getSerializableExtra("book");
        booktype.setText(book.get(5).getType());
        bookname.setText(book.get(5).getName());
    }
}