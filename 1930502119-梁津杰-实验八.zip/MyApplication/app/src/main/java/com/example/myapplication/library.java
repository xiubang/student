package com.example.myapplication;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
public class library extends Activity {
    private List<book> book = new ArrayList<>();
    MyDatabaseHelper database = new MyDatabaseHelper(this, "library.db", null, 1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initbook();
        setContentView(R.layout.activity_library);
        Button add = findViewById(R.id.add);
        Button create = findViewById(R.id.create);
        Button check = findViewById(R.id.check);
        bookAdapter adapter = new bookAdapter(library.this,
                R.layout.book_item, book);
        ListView checkbook = findViewById(R.id.checkbook);
        EditText typex = findViewById(R.id.type);
        EditText namex = findViewById(R.id.name);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                database.getWritableDatabase();
            }
        });
        typex.setText(typex.getText().toString());
        namex.setText(namex.getText().toString());
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String booktype = typex.getText().toString();
                String bookname = namex.getText().toString();
                System.out.println(booktype + "    " + bookname);
                Context mContext = null;
                SQLiteDatabase db = database.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("name", bookname);
                values.put("type", booktype);
                System.out.println("bookname:" + values.get("name") +
                        "   booktype" + values.get("type"));
                db.insert("book", null, values);
                Log.d("insert succeeded" + values.toString(), null, null);
                values.clear();
            }
        });
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = database.getWritableDatabase();
                Cursor cursor = db.query("book", null, null,
                        null, null, null, null);
                if (cursor.moveToFirst()) {
                    do {
                        @SuppressLint("Range")
                        String type = cursor.getString(cursor.getColumnIndex("type"));
                        @SuppressLint("Range")
                        String name = cursor.getString(cursor.getColumnIndex("name"));
                        Log.d("book:",type+"   "+name);
                    } while (cursor.moveToNext());
                }
                cursor.close();
            }
        });
        checkbook.setAdapter(adapter);
        checkbook.setOnItemClickListener((parent, view, position, id) -> {
            book books = book.get(position);
            Toast.makeText(library.this, books.getName(),
                    Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(library.this, ItemDetailActivity1.class);
            intent.putExtra("type",books.getType());
            intent.putExtra("name",books.getName());
            SQLiteDatabase db = database.getWritableDatabase();
            Cursor cursor = db.query("book", null, null,
                    null, null, null, null);
            if (cursor.moveToFirst()) {
                do {
                    book b=new book();
                    @SuppressLint("Range")
                    String type = cursor.getString(cursor.getColumnIndex("type"));
                    @SuppressLint("Range")
                    String name = cursor.getString(cursor.getColumnIndex("name"));
//                    b=initbook(type,name);
                    book.add(b);
                } while (cursor.moveToNext());
                startActivity(intent);
            }
            cursor.close();
        });
    }
    private void initbook(){
        SQLiteDatabase db = database.getWritableDatabase();
        Cursor cursor = db.query("book", null, null,
                null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                book b=new book();
                @SuppressLint("Range")
                String typex = cursor.getString(cursor.getColumnIndex("type"));
                @SuppressLint("Range")
                String namex = cursor.getString(cursor.getColumnIndex("name"));
                book.add(b);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}