package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class SuccessActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);
        TextView un=findViewById(R.id.username);
        TextView pw=findViewById(R.id.password);
        Button go=findViewById(R.id.go);
        ListView checkbook = findViewById(R.id.checkbook);
        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");
        un.setText(username);
        pw.setText(password);
        MyDatabaseHelper database=new MyDatabaseHelper(this,"book.db",null,1);
        go.setOnClickListener(v -> {
                Intent intent2 = new Intent(SuccessActivity.this, library.class);
                startActivity(intent2);
        });
    }
}