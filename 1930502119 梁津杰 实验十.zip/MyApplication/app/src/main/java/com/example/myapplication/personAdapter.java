package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class personAdapter extends ArrayAdapter<person> {
    private int id;
    public personAdapter(Context context, int textViewResourceId, List<person>objects){
        super(context,textViewResourceId,objects);
        id=textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        person person=getItem(position);
        View view= LayoutInflater.from((getContext())).inflate(id,parent,false);
        TextView person_name=(TextView)view.findViewById(R.id.person_name);
        TextView num=(TextView)view.findViewById(R.id.number);
        person_name.setText(person.getName());
        num.setText(person.getNum());
        return view;
    }
}
