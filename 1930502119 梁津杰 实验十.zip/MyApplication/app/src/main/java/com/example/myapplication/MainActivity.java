package com.example.myapplication;
/*
创建person表：
create table person(name text,numbers text);
 */
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private List<person> person = new ArrayList<>();
    MyDatabaseHelper database = new MyDatabaseHelper(this, "library.db", null, 1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initperson();
        personAdapter adapter=new personAdapter(MainActivity.this,
                R.layout.person_item, person);
        ListView lv= (ListView) findViewById(R.id.personname);
        Button addperosn=findViewById(R.id.addperson);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((parent, view, position, id) -> {
            person pnx = person.get(position);
            Intent intent = new Intent(MainActivity.this,
                    Message.class);
            intent.putExtra("pn",pnx.getName());
            intent.putExtra("numbers",pnx.getNum());
            startActivity(intent);
        });
        /*
        添加数据库联系人
         */
        addperosn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,
                        add_person.class);
                startActivity(intent);
            }
        });
    }

    private void initperson(){
        /*
        数据库联系人
         */
//        SQLiteDatabase db = database.getWritableDatabase();
//        Cursor cursor = db.query("person", null, null,
//                null,null, null, null);
        /*
        系统通讯录
         */
        Cursor cursor=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,null,null,null);
        if (cursor.moveToFirst()) {
            do {
                person p=new person();
                @SuppressLint("Range")
//                String namex = cursor.getString(cursor.getColumnIndex("name"));
                String namex=cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                p.setName(namex);
                @SuppressLint("Range")
//                String numbersx = cursor.getString(cursor.getColumnIndex("numbers"));
                String numbersx=cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                p.setNum(numbersx);
                this.person.add(p);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}