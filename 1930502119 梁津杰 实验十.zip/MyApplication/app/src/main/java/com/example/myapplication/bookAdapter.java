package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class bookAdapter extends ArrayAdapter<book> {
    private int id;
    public bookAdapter(Context context, int textViewResourceId, List<book>objects){
        super(context,textViewResourceId,objects);
        id=textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        book b=getItem(position);
        View view= LayoutInflater.from((getContext())).inflate(id,parent,false);
        TextView booktypex=view.findViewById(R.id.booktypex);
        TextView booknamex=view.findViewById(R.id.booknamex);
        booktypex.setText(b.getType());
        booknamex.setText(b.getName());
        return view;
    }
}
