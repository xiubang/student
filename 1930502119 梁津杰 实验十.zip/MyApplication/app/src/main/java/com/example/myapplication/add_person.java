package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class add_person extends AppCompatActivity {
    MyDatabaseHelper database = new MyDatabaseHelper(this, "library.db", null, 1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_person);
        EditText editname=findViewById(R.id.editname);
        EditText editnubmers=findViewById(R.id.editnumbers);
        Button add=findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String personname = editname.getText().toString();
                String personnubmers = editnubmers.getText().toString();
                System.out.println(personname + "    " + personnubmers);
                Context mContext = null;
                SQLiteDatabase db = database.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("name", personname);
                values.put("numbers", personnubmers);
                System.out.println("name:" + values.get("name") +
                        "   numbers" + values.get("type"));
                db.insert("person", null, values);
                Log.d("insert succeeded" + values.toString(), null, null);
                values.clear();
            }
        });
    }
}