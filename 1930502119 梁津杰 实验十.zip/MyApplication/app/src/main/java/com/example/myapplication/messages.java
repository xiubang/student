package com.example.myapplication;

public class messages {
    private String name;
    private String message;

    @Override
    public String toString() {
        return "messages{" +
                "name='" + name + '\'' +
                ", message='" + message + '\'' +
                '}';
    }

    public messages(String name, String message) {
        this.name = name;
        this.message = message;
    }

    public messages() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
