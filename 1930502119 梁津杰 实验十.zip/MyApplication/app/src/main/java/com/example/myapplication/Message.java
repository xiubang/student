package com.example.myapplication;
/*
创建message表：
create table message(name text,mes text);
 */

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Message extends Activity {
    MyDatabaseHelper database = new MyDatabaseHelper(this, "library.db", null, 1);
    Button sender;
    Button take_p;
    ListView histort_mes;
    EditText content;
    TextView details;
    String personname;
    private List<messages> messagesList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        this.sender=findViewById(R.id.send);
        this.take_p=findViewById(R.id.photo);
        this.histort_mes=findViewById(R.id.history_mes);
        this.content=findViewById(R.id.edit_mes);
        this.details=findViewById(R.id.details);
        this.take_p=findViewById(R.id.photo);
        IntentFilter receivefilter= new IntentFilter();
        receivefilter.addAction("android.provider.Telephony.SMS_RECEIVED");
        MessageReceiver messagereceiver= new MessageReceiver();
//        registerReceiver(messagereceiver, receivefilter);
        Intent intent = getIntent();
        this.personname= intent.getStringExtra("pn");
        String numbers = intent.getStringExtra("numbers");
        details.setText("联系人："+personname+"     联系电话"+numbers);
        /*
        发送的短信存到数据库中
         */
        sender.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {
                                          String context =content.getText().toString();//短信内容
                                          SQLiteDatabase db = database.getWritableDatabase();
                                          ContentValues values = new ContentValues();
                                          values.put("name", personname);
                                          values.put("mes", context);
                                          db.insert("message", null, values);
                                          Log.d("insert succeeded" + values.toString(), null, null);
                                          values.clear();
                                      }
                                  }
        );
        mesAdapter adapter = new mesAdapter(Message.this,
                R.layout.message_item, messagesList);
        initmes();
        histort_mes.setAdapter(adapter);
    }
    public void startCamera(View view){
        Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivity(intent);
    }
    private void initmes(){
        SQLiteDatabase db = database.getWritableDatabase();
        Cursor cursor = db.query("message", null, "name=?",
                new String[]{personname}, null, null, null);
//
        if (cursor.moveToFirst()) {
            do {
                messages m=new messages();
                @SuppressLint("Range")
                String namex = cursor.getString(cursor.getColumnIndex("name"));
                m.setName(namex);
                @SuppressLint("Range")
                String messagex = cursor.getString(cursor.getColumnIndex("mes"));
                m.setMessage(messagex);
                this.messagesList.add(m);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
    class MessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            Object[] pdus = (Object[]) bundle.get("pdus"); // 提取短信消息
            SmsMessage[] messages = new SmsMessage[pdus.length];
            for (int i = 0; i < messages.length; i++) {
                messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
            }
            String address = messages[0].getOriginatingAddress(); // 获取发送方号码
            String fullMessage = "";
            for (SmsMessage message : messages) {
                fullMessage += message.getMessageBody(); // 获取短信内容
            }
        }
    }
}

