package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class mesAdapter extends ArrayAdapter<messages> {
    private int id;
    public mesAdapter(Context context, int textViewResourceId, List<messages>objects){
        super(context,textViewResourceId,objects);
        id=textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        messages mess=getItem(position);
        View view= LayoutInflater.from((getContext())).inflate(id,parent,false);
        TextView person_name=(TextView)view.findViewById(R.id.person_name);
        TextView mes=(TextView)view.findViewById(R.id.message);
        person_name.setText(mess.getName());
        mes.setText(mess.getMessage());
        return view;
    }
}
